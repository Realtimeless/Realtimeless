
0000  00000 0   0 0000   0000 00000 00000   0   0   0
0   0 0     0   0     0 0       0   0      0 0  00 00
0   0 00000  0 0   000   000    0   00000  000  0 0 0
0   0 0      0 0  0         0   0   0     0   0 0   0
0000  00000   0   00000 0000    0   00000 0   0 0   0

Presents
==================================
Puyo Puyo Tetris 2 Steam Optimizer
==================================
This program will eliminate Lag and slowdowns in Puyo Puyo Tetris 2 for Non-AVX Supported CPUs or Integrated GPUs.

It gets from 30fps with slowdowns into 60fps without slowdowns.